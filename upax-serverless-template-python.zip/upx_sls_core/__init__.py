description = 'UPAX Serverless Python Package'
author = 'Hugo Gonzalez Rivas'
contact = 'hugo.gonzalezr@elektra.com.mx'
version = '1.0.1'
